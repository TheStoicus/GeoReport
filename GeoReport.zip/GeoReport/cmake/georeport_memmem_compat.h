#ifndef GEOREPORT_MEMMEM_COMPAT_H
#define GEOREPORT_MEMMEM_COMPAT_H

/*
 * macOS does not provide the GNU/POSIX memmem() function in its libc.
 * LibreDWG uses memmem() in generated parser code (acds.spec).
 * This small compatibility implementation is force-included only while
 * compiling LibreDWG, so GeoReport itself is not affected.
 */

#if defined(__APPLE__) && !defined(GEOREPORT_HAS_NATIVE_MEMMEM)
#include <stddef.h>
#include <string.h>

static inline void *georeport_memmem(const void *haystack,
                                     size_t haystack_len,
                                     const void *needle,
                                     size_t needle_len)
{
    if (needle_len == 0)
        return (void *)haystack;

    if (haystack == NULL || needle == NULL || needle_len > haystack_len)
        return NULL;

    const unsigned char *h = (const unsigned char *)haystack;
    const unsigned char *n = (const unsigned char *)needle;

    for (size_t i = 0; i <= haystack_len - needle_len; ++i)
    {
        if (h[i] == n[0] &&
            (needle_len == 1 || memcmp(h + i, n, needle_len) == 0))
        {
            return (void *)(h + i);
        }
    }

    return NULL;
}

#define memmem georeport_memmem
#endif

#endif
